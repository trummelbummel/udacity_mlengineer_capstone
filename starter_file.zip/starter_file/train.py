from sklearn.ensemble import RandomForestClassifier
from imblearn.metrics import sensitivity_score, geometric_mean_score

import argparse

import os
import numpy as np

import pandas as pd
from azureml.core.run import Run
from azureml.data.dataset_factory import TabularDatasetFactory
from azureml.core import Dataset, Datastore
from azureml.data.datapath import DataPath
from azureml.core.model import Model
from azureml.core import Workspace, Dataset





def main():
    # Add arguments to script
    parser = argparse.ArgumentParser()

    parser.add_argument('--n_estimators', type=float, default=100, help="Number of decision trees.")
    parser.add_argument('--min_samples_leaf', type=int, default=3, help="Maximum number of samples in the leaf nodes")

    args = parser.parse_args()

    run = Run.get_context()

    run.log("n estimators:", np.float(args.C))
    run.log("min samples in leaf nodes:", np.int(args.max_iter))

    # TODO: introduce link of datasets here
    #subscription_id = 'f9d5a085-54dc-4215-9ba6-dad5d86e60a0'
    #resource_group = 'aml-quickstarts-201367'
    #workspace_name = 'quick-starts-ws-201367'

    #workspace = Workspace(subscription_id, resource_group, workspace_name)

    #test_data = Dataset.get_by_name(workspace, name='test_project').to_pandas_dataframe()
    #train_data = Dataset.get_by_name(workspace, name='train_project').to_pandas_dataframe()
    test_data = Dataset.Tabular.from_delimited_files(path='https://mlstrg201367.blob.core.windows.net/azureml-blobstore-659db4de-71ba-4733-887f-6bc9a97daa39/UI/07-18-2022_065802_UTC/X_test_vocp_2.csv')
    train_data = Dataset.Tabular.from_delimited_files(path='https://mlstrg201367.blob.core.windows.net/azureml-blobstore-659db4de-71ba-4733-887f-6bc9a97daa39/UI/07-18-2022_062605_UTC/X_train_wcciqs5vocp_resampled_2.csv') 
  
    
    validation_data = validation_data.set_index('Column1')
    featurecols = validation_data.columns.tolist()
    featurecols.remove(label)
    X_val = validation_data[featurecols]
    y_val = validation_data[label]

    train_data = train_data.set_index('Column1')
    X_train = train_data[featurecols]
    y_train = train_data[label]

    model = RandomForestClassifier(n_estimators=args.n_estimators, class_weight='balanced', 
                                    n_jobs=-1, min_samples_leaf=args.min_samples_leaf).fit(X_train, y_train)

    y_pred = model.predict(X_val)
    balanced_accuracy = geometric_mean_score(y_val, y_pred)
    #balanced_sensitivity_score = sensitivity_score(y_val, y_pred, average='weighted')

    run.log("accuracy", np.float(balanced_accuracy))
    #run.log("sensitivity", np.float(balanced_sensitivity_score))
    os.makedirs("./outputs/model", exist_ok=True)
    joblib.dump(value=model, filename="./outputs/model/randomforest.pkl") 
    return 

if __name__ == '__main__':
    main()