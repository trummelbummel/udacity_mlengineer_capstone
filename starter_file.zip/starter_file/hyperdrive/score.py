import os
import logging
import json
import numpy
import joblib
import time

def init():
    """
    Initialize the model during container creation.
    """
    global model
    model_path = os.path.join(os.environ['AZUREML_MODEL_DIR'],"randomforest.pkl")
    # deserialize the model file back into a sklearn model
    model = joblib.load(model_path)
    logging.info("Initialized model as global variable.")


def run(raw_data):
    """
    Inference with trained model.
    """
    logging.info("REST API request received.")
    data = numpy.array(json.loads(raw_data)["data"])
    data = numpy.array(data)
    start = time.perf_counter()
    result = model.predict(data)
    inference_time = time.perf_counter() - start
    logging.info("Inference completed in ms:")
    logging.info(str(inference_time))
    logging.info("Return result")
    return result.tolist()