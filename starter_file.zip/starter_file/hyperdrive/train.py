from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
import argparse

import os
import numpy as np
import joblib 

import pandas as pd
from azureml.core.run import Run
from azureml.data.dataset_factory import TabularDatasetFactory
from azureml.core import Dataset, Datastore
from azureml.data.datapath import DataPath
from azureml.core.model import Model
from azureml.core import Workspace, Dataset
from azureml.core.authentication import AzureCliAuthentication


def main():
    # Add arguments to script
    parser = argparse.ArgumentParser()

    parser.add_argument('--n_estimators', type=int, default=100, help="Number of decision trees.")
    parser.add_argument('--min_samples_leaf', type=int, default=3, help="Maximum number of samples in the leaf nodes")
    #parser.add_argument('--auth', help='details for workspace authentication')

    args = parser.parse_args()

    run = Run.get_context()
    workspace = run.experiment.workspace

    run.log("n estimators:", np.int(args.n_estimators))
    run.log("min samples in leaf nodes:", np.int(args.min_samples_leaf))

   
    label = 'vfc_level2_3_name'

    validation_data = Dataset.get_by_name(workspace, name='test_project').to_pandas_dataframe()
    train_data = Dataset.get_by_name(workspace, name='train_project').to_pandas_dataframe()  
  
    subset_mvp = ['All-round view : View/restricted panoramic view', 'Android Auto : Malfunction', 'Apps (A4A) : Not user-friendly', 'Comfort Access : Not user-friendly', 'Connected App : Malfunction', 'Convertible top / hardtop, open / close : Malfunction', 'Cushioning / damping vehicle : Malfunction', 'Display Key, use : Malfunction', 'Driver profile : Not user-friendly', 'Drivetrain : Customer request: function', 'Driving experience, configuration : Not user-friendly', 'Electric Range : Range, not OK', 'Exterior lighting : Light intensity not OK', 'Headrest, adjust : Malfunction', 'High voltage battery : Malfunction', 'Hood : Damage', 'Instrument cluster : Not user-friendly', 'Lane departure warning : Not user-friendly', 'Manage / connect mobile device (WiFi) : Not user-friendly', 'Navigation : Not user-friendly', 'Operate gear selector switch : Not user-friendly', 'Panorama glass roof : Damage', 'Parking Assistant : Not user-friendly', 'RSC tire : Not user-friendly', 'Seat belts : Not (sufficiently) comfortable', 'Seat belts : Not user-friendly', 'Seating, ventilate / heat : Not user-friendly', 'Side window, open / close : Malfunction', 'Steering wheel : Noise', 'Steering wheel : Not user-friendly', 'Touch screen, operation : Dirty contamination', 'Vehicle, climatization : Condensation', 'Voice control / speech recognition : Malfunction', 'Voice control / speech recognition : Not user-friendly', 'Wheels / tires : Damage', 'good', 'speech input / speech recognition : Not user-friendly']
    
    goodones = [x for x in pd.unique(train_data[label].dropna()) if ('like' in x.lower()) or ('appeals' in x.lower()) and x != 'Ergonomics do not appeal'] + [x for x in pd.unique(validation_data[label].dropna()) if ('like' in x.lower()) or ('appeals' in x.lower()) and x != 'Ergonomics do not appeal' ] 

    validation_data = validation_data[validation_data[label].isin(subset_mvp)].set_index('Column1')
    featurecols = validation_data.columns.tolist()
    featurecols.remove(label)
    X_val = validation_data[featurecols]
    y_val = validation_data[label].apply(lambda x : 'good' if x in goodones else x)

    train_data = train_data[train_data[label].isin(subset_mvp)].set_index('Column1')
    X_train = train_data[featurecols]
    y_train = train_data[label].apply(lambda x : 'good' if x in goodones else x)

    model = RandomForestClassifier(n_estimators=args.n_estimators, class_weight='balanced', 
                                    n_jobs=-1, min_samples_leaf=args.min_samples_leaf).fit(X_train, y_train)

    y_pred = model.predict(X_val)
    f1score = f1_score(y_val, y_pred, average='weighted')

    run.log("f1_score", np.float(f1score))
    os.makedirs("./outputs/model", exist_ok=True)
    joblib.dump(value=model, filename="./outputs/model/randomforest.pkl") 
    return 

if __name__ == '__main__':
    main()